""" Layla Nettavong
M04Programming 11.1
Just to move a function from anouther file onto this file
"""
import hours.py
