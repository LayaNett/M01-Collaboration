""" Layla Nettavong
M04Programming 11.1
The module that'll get imported into zoo.py
"""

def hours():
    print("Open 9-5")